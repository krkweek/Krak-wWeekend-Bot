import logging
from aiogram import Bot, Dispatcher, types, executor
import os
from dotenv import load_dotenv

load_dotenv()

API_TOKEN = os.getenv("TOKEN")
GROUP_ID = os.getenv("GROUP_ID")

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# Удаление ссылок на другие Telegram-группы
@dp.message_handler(lambda message: "t.me/" in message.text or "telegram.me/" in message.text)
async def delete_links(message: types.Message):
    await message.delete()

# Обработка новых участников (например, анкета)
@dp.message_handler(content_types=types.ContentType.NEW_CHAT_MEMBERS)
async def on_user_joined(message: types.Message):
    for new_member in message.new_chat_members:
        await message.answer(f"Привет, {new_member.full_name}! Расскажи о себе :)")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)

# Krakow Weekend Bot 🇵🇱

Telegram-бот для сообщества Krakow Weekend:
- Верификация участников
- Удаление ссылок
- Создание мероприятий
- Пинг всех участников

## Установка
pip install -r requirements.txt  
python bot.py

## Для Render:
Build command: pip install -r requirements.txt  
Start command: python bot.py

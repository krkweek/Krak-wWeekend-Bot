import os
from flask import Flask, request
from telegram import Update, ChatPermissions, Bot
from telegram.ext import Dispatcher, MessageHandler, Filters, ChatMemberHandler

app = Flask(__name__)
TOKEN = os.getenv('TOKEN')
bot = Bot(TOKEN)
dp = Dispatcher(bot, None, workers=0, use_context=True)

GROUP_ID = os.getenv('GROUP_ID')

def delete_links(update: Update, context):
    msg = update.message
    if msg and msg.text and ('t.me/' in msg.text or 'telegram.me/' in msg.text):
        try:
            msg.delete()
        except Exception as e:
            print("Удаление ссылки:", e)

def new_member(update: Update, context):
    member = update.chat_member.new_chat_members[0]
    chat = update.chat_member.chat
    bot.restrict_chat_member(
        chat.id, member.id,
        permissions=ChatPermissions(can_send_messages=False)
    )
    bot.send_message(
        chat.id,
        f"👋 Привет, {member.first_name}! Пожалуйста, расскажи о себе — чтобы получить доступ."
    )

def handle_intro(update: Update, context):
    user = update.effective_user
    chat = update.effective_chat
    bot.restrict_chat_member(
        chat.id, user.id,
        permissions=ChatPermissions(
            can_send_messages=True,
            can_send_media_messages=True,
            can_add_web_page_previews=True,
            can_send_other_messages=True
        )
    )
    update.message.reply_text("Спасибо! Ты получил доступ ✅")

dp.add_handler(MessageHandler(Filters.text & Filters.group, delete_links))
dp.add_handler(ChatMemberHandler(new_member, ChatMemberHandler.CHAT_MEMBER))
dp.add_handler(MessageHandler(Filters.text & Filters.group, handle_intro))

@app.route('/telegram', methods=['POST'])
def webhook():
    update = Update.de_json(request.get_json(force=True), bot)
    dp.process_update(update)
    return 'OK'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', 5000)))

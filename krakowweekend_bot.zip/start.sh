#!/usr/bin/env bash
export TOKEN="$TOKEN"
export GROUP_ID="$GROUP_ID"
gunicorn --bind 0.0.0.0:$PORT main:app
